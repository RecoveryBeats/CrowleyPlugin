#include "ClipperProcessor.h"
#include <cmath>

ClipperProcessor::ClipperProcessor()
{
    updateCoefficients();
}

void ClipperProcessor::prepare (double sr)
{
    sampleRate = sr;
    updateCoefficients();
    reset();
}

void ClipperProcessor::reset()
{
    smAmount   = 0.0f;
    prevSample = 0.0f;
}

void ClipperProcessor::setAmount (float v)
{
    amount = juce::jlimit (0.0f, 1.0f, v);
}

void ClipperProcessor::setMode (int m)
{
    mode = juce::jlimit (0, 2, m);
}

void ClipperProcessor::updateCoefficients()
{
    smCoeff = makeCoeff (0.010f, sampleRate); // 10 ms smoothing
}

// ── Clipping algorithms ───────────────────────────────────────────────────────

// Cubic soft-clip: true polynomial, no division artefact
// Clips smoothly into ±th, unity gain below th*2/3
float ClipperProcessor::softClip (float x, float th)
{
    if (std::abs (x) >= th)
    {
        const float sign = x >= 0.0f ? 1.0f : -1.0f;
        return sign * th;  // hard limit at threshold (cubic region ends here)
    }

    // Three-region cubic: below 2/3*th linear, above soft knee
    const float knee = th * (2.0f / 3.0f);
    if (std::abs (x) <= knee)
        return x;

    // Cubic interpolation in knee region
    const float sign  = x >= 0.0f ? 1.0f : -1.0f;
    const float norm  = (std::abs (x) - knee) / (th - knee);   // 0..1
    const float cubic = norm * norm * (3.0f - 2.0f * norm);     // smooth-step
    return sign * (knee + cubic * (th - knee));
}

// Brickwall hard clip
float ClipperProcessor::hardClip (float x, float th)
{
    return juce::jlimit (-th, th, x);
}

// Diode: asymmetric – negative half hard clips slightly earlier than positive
// Creates 2nd-order harmonic character (vintage transistor character)
float ClipperProcessor::diodeClip (float x, float th)
{
    if (x >= 0.0f)
        return softClip (x, th);

    // Negative half clips at 85% of threshold, creating asymmetry
    const float negTh = th * 0.85f;
    return softClip (x, negTh);
}

// ── processBlock ─────────────────────────────────────────────────────────────

void ClipperProcessor::processBlock (float* buffer, int numSamples)
{
    if (amount < 0.001f && smAmount < 0.001f)
        return;

    for (int i = 0; i < numSamples; ++i)
    {
        // Smooth amount at audio rate
        smAmount += (amount - smAmount) * (1.0f - smCoeff);
        if (smAmount < 0.0001f)
        {
            prevSample = buffer[i];
            continue;
        }

        // Threshold: maps 0..1 amount to 1.0..0.25 threshold
        // Using square-root taper for more musical response at low amounts
        const float normAmt = std::sqrt (juce::jlimit (0.0f, 1.0f, smAmount));
        const float th = juce::jlimit (0.25f, 1.0f, 1.0f - normAmt * 0.75f);

        // ── Inter-sample peak estimation ─────────────────────────────────
        // Check if a linear interpolation peak between prev and current
        // sample would exceed the threshold.  If so, use the clipped
        // mid-point as a correction factor.  This catches clipping that
        // would otherwise alias through a pure sample-domain clipper.
        const float cur  = buffer[i];
        const float mid  = (prevSample + cur) * 0.5f;
        float corrected  = cur;
        if (std::abs (mid) > th)
        {
            // Apply a mild correction proportional to the overshoot
            const float excess = std::abs (mid) - th;
            const float corrFactor = 1.0f - excess * 0.5f;
            corrected = cur * juce::jlimit (0.5f, 1.0f, corrFactor);
        }

        // ── Clip ─────────────────────────────────────────────────────────
        float y = 0.0f;
        switch (mode)
        {
            case 0: y = softClip  (corrected, th); break;
            case 1: y = hardClip  (corrected, th); break;
            case 2: y = diodeClip (corrected, th); break;
            default: y = corrected; break;
        }

        // ── Gain compensation ─────────────────────────────────────────────
        // Normalize so RMS perceived loudness stays roughly consistent.
        // As threshold drops, we boost slightly to compensate for RMS loss.
        const float comp = 1.0f + normAmt * 0.35f;
        y *= comp;

        prevSample = buffer[i];
        buffer[i]  = juce::jlimit (-2.0f, 2.0f, y);
    }
}
