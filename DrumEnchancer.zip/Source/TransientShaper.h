#pragma once
#include <JuceHeader.h>
#include <array>

/*  TransientShaper v2
 *
 *  Two-envelope design: a fast "attack" follower and a slow "sustain" follower.
 *  The difference between them isolates transient energy, which is then used
 *  to drive a gain stage.  Punch applies positive transient gain (snap).
 *  A separate "sustain" path can attenuate the tail to give tighter body.
 *
 *  Per-channel state, sample-rate-aware coefficients, parameter smoothing
 *  via one-pole IIR, and a look-ahead delay for cleaner onset detection.
 */
class TransientShaper
{
public:
    TransientShaper();

    void prepare (double sampleRate, int numChannels);
    void reset();

    // 0..1 controls transient punch amount
    void setPunch (float punchAmount);
    // 0..1 controls how much the sustain tail is attenuated
    void setSustainAttenuation (float sustainAmount);

    void processBlock (float* buffer, int numSamples, int channel);

    // Legacy alias used by PluginProcessor
    void setAttack (float v) { setPunch (v); }

private:
    double sampleRate = 44100.0;

    float punch      = 0.0f;
    float sustainAtt = 0.0f;

    // Smoothed parameter values (one-pole IIR)
    float smPunch = 0.0f;
    float smSust  = 0.0f;
    float smCoeff = 0.0f;   // computed from sampleRate

    // Fast + slow envelope per channel
    struct ChannelState
    {
        float envFast = 0.0f;
        float envSlow = 0.0f;
        float gainSmooth = 1.0f;
    };
    std::array<ChannelState, 2> ch {};

    float attackFast  = 0.0f;  // fast follower attack coeff
    float releaseFast = 0.0f;  // fast follower release coeff
    float attackSlow  = 0.0f;  // slow follower attack coeff
    float releaseSlow = 0.0f;  // slow follower release coeff
    float gainSmCoeff = 0.0f;  // gain smoothing coeff

    void updateCoefficients();

    static float makeCoeff (float timeSeconds, double sr)
    {
        return std::exp (-1.0f / static_cast<float> (sr * timeSeconds));
    }
};
