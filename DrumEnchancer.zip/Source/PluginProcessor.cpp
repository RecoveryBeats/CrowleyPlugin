#include "PluginEditor.h"
#include "PluginProcessor.h"

namespace
{
    const juce::Colour bgColour(0xFF141414);
    const juce::Colour headerColour(0xFF0B0B0D);
    const juce::Colour presetBarColor(0xFF101012);
    const juce::Colour panelColour(0xFF111111);
    const juce::Colour borderColour(0xFF1E1E1E);
    const juce::Colour softText(0xFF2F2F34);
    const juce::Colour labelText(0xFF4A4A52);
    const juce::Colour accent(0xFFE8C84A);
    const juce::Colour footerText(0xFF555555);

    void drawPanel(juce::Graphics& g, juce::Rectangle<int> area, const juce::String& title)
    {
        auto r = area.toFloat();

        g.setColour(panelColour);
        g.fillRoundedRectangle(r, 12.0f);

        g.setColour(borderColour);
        g.drawRoundedRectangle(r.reduced(0.5f), 12.0f, 1.0f);

        auto titleArea = area.removeFromTop(20);
        g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 8.0f, juce::Font::bold));
        g.setColour(softText);
        g.drawText(title, titleArea.reduced(12, 0), juce::Justification::centredLeft);

        const int lineX = titleArea.getX() + 88;
        g.setColour(borderColour);
        g.fillRect(lineX, titleArea.getCentreY(), juce::jmax(12, titleArea.getRight() - lineX - 12), 1);
    }

    void drawSectionLabel(juce::Graphics& g, const juce::String& text, juce::Rectangle<int> area)
    {
        g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 8.0f, juce::Font::plain));
        g.setColour(softText);
        g.drawText(text, area, juce::Justification::centredLeft);
    }
}

RehabAudioProcessorEditor::RehabAudioProcessorEditor(RehabAudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    setLookAndFeel(&rehabLAF);

    modeLabel.setText("DRUM MODE", juce::dontSendNotification);
    modeLabel.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 8.0f, juce::Font::bold));
    modeLabel.setColour(juce::Label::textColourId, juce::Colour(0xFF3D3D45));
    modeLabel.setJustificationType(juce::Justification::centredRight);
    addAndMakeVisible(modeLabel);

    drumModeBox.addItemList({ "808", "Kick", "Snare", "Closed Hat", "Open Hat" }, 1);
    addAndMakeVisible(drumModeBox);
    drumModeAttachment.reset(new ComboBoxAttachment(audioProcessor.getAPVTS(), "drumMode", drumModeBox));

    satTypeBox.addItemList({ "Soft", "Tube", "Clip" }, 1);
    addAndMakeVisible(satTypeBox);
    satTypeAttachment.reset(new ComboBoxAttachment(audioProcessor.getAPVTS(), "satType", satTypeBox));

    clipModeBox.addItemList({ "Soft", "Hard" }, 1);
    addAndMakeVisible(clipModeBox);
    clipModeAttachment.reset(new ComboBoxAttachment(audioProcessor.getAPVTS(), "clipMode", clipModeBox));

    auto attach = [this](LabelledKnob& k, const juce::String& id, std::unique_ptr<SliderAttachment>& a)
        {
            addAndMakeVisible(k);
            a.reset(new SliderAttachment(audioProcessor.getAPVTS(), id, k.slider));
        };

    attach(hitKnob, "hit", hitAttachment);
    attach(punchKnob, "punch", punchAttachment);
    attach(toneKnob, "tone", toneAttachment);
    attach(satDriveKnob, "satDrive", satDriveAttachment);
    attach(clipAmountKnob, "clipAmount", clipAmountAttachment);
    attach(mixKnob, "mix", mixAttachment);
    attach(outputKnob, "output", outputAttachment);

    addAndMakeVisible(waveformDisplay);
    addAndMakeVisible(inMeter);
    addAndMakeVisible(outMeter);

    setSize(1320, 700);
}

RehabAudioProcessorEditor::~RehabAudioProcessorEditor()
{
    setLookAndFeel(nullptr);
}

void RehabAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(bgColour);

    const int headerH = 88;
    const int presetBarH = 54;
    const int footerH = 36;

    g.setColour(headerColour);
    g.fillRect(0, 0, getWidth(), headerH);

    g.setColour(accent);
    g.fillRect(0, 0, getWidth(), 2);

    g.setColour(borderColour);
    g.fillRect(0, headerH - 1, getWidth(), 1);

    g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 28.0f, juce::Font::bold));
    g.setColour(accent);
    g.drawText("REHAB", 0, 18, getWidth(), 28, juce::Justification::centred);

    g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::plain));
    g.setColour(juce::Colour(0xFF4D4D55));
    g.drawText("MODULAR DRUM ENHANCER", 0, 50, getWidth(), 12, juce::Justification::centred);

    g.setColour(juce::Colour(0x33E8C84A));
    g.fillRect(getWidth() / 2 - 80, 68, 160, 1);

    g.setColour(presetBarColor);
    g.fillRect(0, headerH, getWidth(), presetBarH);

    g.setColour(accent);
    g.fillRect(0, headerH, getWidth(), 1);

    g.setColour(borderColour);
    g.fillRect(0, headerH + presetBarH - 1, getWidth(), 1);

    auto body = getLocalBounds().withTop(headerH + presetBarH).reduced(30, 18);

    drawSectionLabel(g, "TRANSIENT", { body.getX() + 70, body.getY(), 100, 12 });
    drawSectionLabel(g, "COLOUR", { body.getX() + 500, body.getY(), 100, 12 });
    drawSectionLabel(g, "OUTPUT", { body.getRight() - 285, body.getY(), 100, 12 });

    auto waveformFrame = juce::Rectangle<int>(body.getX(), body.getY() + 14, body.getWidth(), 146);
    g.setColour(panelColour);
    g.fillRoundedRectangle(waveformFrame.toFloat(), 12.0f);
    g.setColour(borderColour);
    g.drawRoundedRectangle(waveformFrame.toFloat().reduced(0.5f), 12.0f, 1.0f);

    const int panelsTop = waveformFrame.getBottom() + 24;
    const int gap = 22;
    const int panelHeight = body.getBottom() - panelsTop - footerH - 8;

    const int meterW = 56;
    const int transientPanelW = 370;
    const int colourPanelW = 430;
    const int outputPanelW = body.getWidth() - meterW - transientPanelW - colourPanelW - meterW - gap * 4;

    juce::Rectangle<int> inMeterArea(body.getX(), panelsTop, meterW, panelHeight);
    juce::Rectangle<int> transientPanel(inMeterArea.getRight() + gap, panelsTop, transientPanelW, panelHeight);
    juce::Rectangle<int> colourPanel(transientPanel.getRight() + gap, panelsTop, colourPanelW, panelHeight);
    juce::Rectangle<int> outputPanel(colourPanel.getRight() + gap, panelsTop, outputPanelW, panelHeight);
    juce::Rectangle<int> outMeterArea(outputPanel.getRight() + gap, panelsTop, meterW, panelHeight);

    drawPanel(g, transientPanel, "TRANSIENT");
    drawPanel(g, colourPanel, "COLOUR");
    drawPanel(g, outputPanel, "OUTPUT");

    g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 8.0f, juce::Font::bold));
    g.setColour(labelText);
    g.drawText("IN", inMeterArea.getX(), inMeterArea.getY() - 14, inMeterArea.getWidth(), 10, juce::Justification::centred);
    g.drawText("OUT", outMeterArea.getX(), outMeterArea.getY() - 14, outMeterArea.getWidth(), 10, juce::Justification::centred);

    g.drawText("SAT TYPE", colourPanel.getX() + 20, colourPanel.getBottom() - 46, 100, 10, juce::Justification::centredLeft);
    g.drawText("CLIP MODE", outputPanel.getX() + 18, outputPanel.getBottom() - 46, 100, 10, juce::Justification::centredLeft);

    const int footerY = getHeight() - footerH;
    g.setColour(juce::Colour(0xFF0D0D0D));
    g.fillRect(0, footerY, getWidth(), footerH);

    g.setColour(borderColour);
    g.fillRect(0, footerY, getWidth(), 1);

    g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::bold));
    g.setColour(footerText);
    g.drawText("Rehab", 20, footerY + 11, 120, 14, juce::Justification::centredLeft);
    g.drawText("Powered By: Recovery Beats", 0, footerY + 11, getWidth(), 14, juce::Justification::centred);
    g.drawText("V1.0.0.", getWidth() - 120, footerY + 11, 100, 14, juce::Justification::centredRight);
}

void RehabAudioProcessorEditor::resized()
{
    const int W = getWidth();
    const int headerH = 88;
    const int presetBarH = 54;
    const int footerH = 36;

    modeLabel.setBounds(W / 2 - 170, headerH + 18, 100, 14);
    drumModeBox.setBounds(W / 2 - 58, headerH + 10, 228, 30);

    auto body = getLocalBounds().withTop(headerH + presetBarH).reduced(30, 18);

    waveformDisplay.setBounds(body.getX(), body.getY() + 14, body.getWidth(), 146);

    const int panelsTop = body.getY() + 14 + 146 + 24;
    const int gap = 22;
    const int panelHeight = body.getBottom() - panelsTop - footerH - 8;

    const int meterW = 56;
    const int transientPanelW = 370;
    const int colourPanelW = 430;
    const int outputPanelW = body.getWidth() - meterW - transientPanelW - colourPanelW - meterW - gap * 4;

    juce::Rectangle<int> inMeterArea(body.getX(), panelsTop, meterW, panelHeight);
    juce::Rectangle<int> transientPanel(inMeterArea.getRight() + gap, panelsTop, transientPanelW, panelHeight);
    juce::Rectangle<int> colourPanel(transientPanel.getRight() + gap, panelsTop, colourPanelW, panelHeight);
    juce::Rectangle<int> outputPanel(colourPanel.getRight() + gap, panelsTop, outputPanelW, panelHeight);
    juce::Rectangle<int> outMeterArea(outputPanel.getRight() + gap, panelsTop, meterW, panelHeight);

    inMeter.setBounds(inMeterArea);
    outMeter.setBounds(outMeterArea);

    hitKnob.setBounds(transientPanel.getX() + 26, transientPanel.getY() + 56, 162, 210);
    punchKnob.setBounds(transientPanel.getX() + 208, transientPanel.getY() + 82, 128, 166);

    toneKnob.setBounds(colourPanel.getX() + 24, colourPanel.getY() + 58, 118, 156);
    satDriveKnob.setBounds(colourPanel.getX() + 156, colourPanel.getY() + 58, 118, 156);
    clipAmountKnob.setBounds(colourPanel.getX() + 288, colourPanel.getY() + 58, 118, 156);
    satTypeBox.setBounds(colourPanel.getX() + 24, colourPanel.getBottom() - 30, 176, 28);

    mixKnob.setBounds(outputPanel.getX() + 20, outputPanel.getY() + 58, 112, 156);
    outputKnob.setBounds(outputPanel.getX() + 148, outputPanel.getY() + 58, 112, 156);
    clipModeBox.setBounds(outputPanel.getX() + 20, outputPanel.getBottom() - 30, 176, 28);
}