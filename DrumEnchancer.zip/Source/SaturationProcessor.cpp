#include "SaturationProcessor.h"
#include <cmath>

SaturationProcessor::SaturationProcessor()
{
    updateCoefficients();
}

void SaturationProcessor::prepare (double sr)
{
    sampleRate = sr;
    updateCoefficients();
    reset();
}

void SaturationProcessor::reset()
{
    smDrive  = 0.0f;
    dcIn     = 0.0f;
    dcOut    = 0.0f;
    aaState  = 0.0f;
    preState = 0.0f;
}

void SaturationProcessor::setDrive (float v)
{
    drive = juce::jlimit (0.0f, 2.0f, v);
}

void SaturationProcessor::setMode (int m)
{
    mode = juce::jlimit (0, 3, m);
}

void SaturationProcessor::updateCoefficients()
{
    smCoeff = makeCoeff (0.020f, sampleRate);

    // DC blocker: 20 Hz one-pole high-pass
    dcCoeff = makeCoeff (1.0f / (2.0f * juce::MathConstants<float>::pi * 20.0f), sampleRate);

    // Anti-aliasing: gentle 8 kHz low-pass (reduces upper harmonics that alias)
    aaCoeff = makeCoeff (1.0f / (2.0f * juce::MathConstants<float>::pi * 8000.0f), sampleRate);
}

// ── Saturation algorithms ─────────────────────────────────────────────────────

// Tape: symmetric tanh with gain compensation
float SaturationProcessor::tapeSat (float x, float drv)
{
    const float k = 1.0f + drv * 8.0f;
    // Gain-compensated so unity at drv=0
    return std::tanh (x * k) / std::tanh (k * 0.5f + 0.01f);
}

// Tube: asymmetric using negative half-wave bias (even harmonics)
float SaturationProcessor::tubeSat (float x, float drv)
{
    const float k    = 1.0f + drv * 6.0f;
    const float bias = 0.15f * drv;  // slight positive DC shift mimics tube bias
    const float driven = (x + bias) * k;
    const float sat  = driven >= 0.0f
                       ? std::tanh (driven)
                       : std::tanh (driven * 0.7f);  // softer on negative half
    return sat / (1.0f + bias * k * 0.5f);           // DC compensation
}

// Transistor: hard tanh + subtle fold-back for odd harmonic character
float SaturationProcessor::transistorSat (float x, float drv)
{
    const float k  = 1.0f + drv * 12.0f;
    const float th = 0.7f - drv * 0.2f;  // threshold lowers with drive
    float y = x * k;
    // Fold-back: signal above threshold wraps back
    if (y > th)       y = th  - (y - th)  * 0.3f;
    else if (y < -th) y = -th - (y + th)  * 0.3f;
    return juce::jlimit (-1.5f, 1.5f, y) / k * (1.0f + drv * 0.4f);
}

// FET: brighter tanh with harder knee and slight high-frequency emphasis
float SaturationProcessor::fetSat (float x, float drv)
{
    const float k = 1.0f + drv * 15.0f;
    // FET has a harder knee – use x^3 shaper blended with tanh
    const float tanhSat  = std::tanh (x * k);
    const float cubicSat = x * (3.0f - (x * x * k * k)) * (1.0f / 2.0f);
    const float blend    = juce::jlimit (0.0f, 1.0f, drv);
    return (tanhSat * blend + cubicSat * (1.0f - blend)) / (0.5f + drv * 0.5f + 0.01f);
}

// ── processBlock ─────────────────────────────────────────────────────────────

void SaturationProcessor::processBlock (float* buffer, int numSamples)
{
    if (drive < 0.001f && smDrive < 0.001f)
        return;

    for (int i = 0; i < numSamples; ++i)
    {
        // Smooth drive parameter
        smDrive += (drive - smDrive) * (1.0f - smCoeff);
        if (smDrive < 0.0001f) { buffer[i] = buffer[i]; continue; }

        const float x = buffer[i];

        // ── Anti-aliasing pre-filter (mild LP) ───────────────────────────
        // Gently round the waveform before saturation to reduce aliased harmonics
        const float aaMix = juce::jlimit (0.0f, 0.5f, smDrive * 0.3f);
        aaState += (x - aaState) * (1.0f - aaCoeff);
        const float xAA = x + (aaState - x) * aaMix;

        // ── Saturation ───────────────────────────────────────────────────
        float sat = 0.0f;
        switch (mode)
        {
            case 0: sat = tapeSat       (xAA, smDrive); break;
            case 1: sat = tubeSat       (xAA, smDrive); break;
            case 2: sat = transistorSat (xAA, smDrive); break;
            case 3: sat = fetSat        (xAA, smDrive); break;
            default: sat = xAA; break;
        }

        // ── Dry/wet blend proportional to drive ──────────────────────────
        // Keep some dry signal to preserve transient clarity at low drive
        const float wet = juce::jlimit (0.0f, 1.0f, smDrive * 0.8f);
        float y = x * (1.0f - wet) + sat * wet;

        // ── DC blocker (prevents LP interaction from drifting) ────────────
        const float dcInNew = y;
        y = dcCoeff * (dcOut + dcInNew - dcIn);
        dcIn  = dcInNew;
        dcOut = y;

        buffer[i] = juce::jlimit (-2.0f, 2.0f, y);
    }
}
