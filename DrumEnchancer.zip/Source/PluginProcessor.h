#pragma once

#include <JuceHeader.h>
#include "Parameters.h"
#include "TransientShaper.h"
#include "SaturationProcessor.h"
#include "ClipperProcessor.h"

class RehabAudioProcessor : public juce::AudioProcessor
{
public:
    RehabAudioProcessor();
    ~RehabAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    const juce::String getName() const override;
    bool acceptsMidi()  const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() { return apvts; }

private:
    juce::AudioProcessorValueTreeState apvts{ *this, nullptr, "Parameters",
                                               Parameters::createParameterLayout() };

    TransientShaper     transientShaper;
    SaturationProcessor saturationProcessor;
    ClipperProcessor    clipperProcessor;

    // Cached parameter values
    float currentDrumMode = 0.0f;
    float currentHit = 0.0f;
    float currentInputGain = 0.0f;
    float currentTone = 0.0f;
    float currentPunch = 0.0f;
    float currentSatDrive = 0.0f;
    float currentClipAmount = 0.0f;
    float currentMix = 1.0f;
    float currentOutput = 0.0f;

    // Tone state
    std::array<float, 2> lowState{ 0.0f, 0.0f };
    std::array<float, 2> highState{ 0.0f, 0.0f };

    struct ModeScaling
    {
        float transientMultiplier;
        float satMultiplier;
        float clipMultiplier;
        int   satAlgorithm;
        int   clipMode;
    };

    static ModeScaling getModeScaling(int mode);

    void  updateToneState(float input, int channel);
    float applyTone(float input, int channel) const;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RehabAudioProcessor)
};