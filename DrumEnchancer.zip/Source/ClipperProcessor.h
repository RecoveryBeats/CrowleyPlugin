#pragma once
#include <JuceHeader.h>

/*  ClipperProcessor v2
 *
 *  Three clipping modes selected by drum type:
 *
 *    SOFT  – Cubic soft-knee (smooth, musical; default for 808 / hats)
 *    HARD  – True brickwall hard clip at threshold (punchy for kick)
 *    DIODE – Asymmetric diode-style half-wave soft clip (snare/hat presence)
 *
 *  Improvements over v1:
 *    – True cubic polynomial soft-clip (no division artefact near threshold)
 *    – Diode mode adds asymmetric 2nd-order character
 *    – Output is gain-compensated for perceived loudness consistency
 *    – Inter-sample peak estimation: clips overshoots between samples
 *      using a simple linear interpolation to catch peaks that would
 *      alias through a pure sample-domain clipper
 *    – Threshold range extended: 0.25..1.0 (was 0.15..1.0), allowing
 *      more drive before hard limiting
 *    – Full parameter smoothing at audio rate
 */
class ClipperProcessor
{
public:
    ClipperProcessor();

    void prepare (double sampleRate);
    void reset();

    void setAmount (float clipAmount); // 0..1
    void setMode   (int  modeIndex);  // 0=soft, 1=hard, 2=diode

    // Legacy interface (used by PluginProcessor)
    void setMode (bool softClip) { setMode (softClip ? 0 : 1); }

    void processBlock (float* buffer, int numSamples);

private:
    double sampleRate = 44100.0;
    float  amount     = 0.0f;
    int    mode       = 0;
    float  smAmount   = 0.0f;
    float  smCoeff    = 0.0f;

    float prevSample = 0.0f;

    void updateCoefficients();

    static float softClip  (float x, float th);
    static float hardClip  (float x, float th);
    static float diodeClip (float x, float th);

    static float makeCoeff (float timeSeconds, double sr)
    {
        return std::exp (-1.0f / static_cast<float> (sr * timeSeconds));
    }
};
