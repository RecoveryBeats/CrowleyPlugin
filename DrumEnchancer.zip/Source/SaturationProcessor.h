#pragma once
#include <JuceHeader.h>

/*  SaturationProcessor v2
 *
 *  Four saturation algorithms selectable by mode index, chosen automatically
 *  based on the drum mode:
 *
 *    0 – Tape / soft knee  : tanh with pre-emphasis high shelf (adds warmth)
 *    1 – Tube / asymmetric : even-order harmonics, warmer feel (good for kick)
 *    2 – Transistor / fold : adds odd harmonics + subtle fold-back (snare crack)
 *    3 – FET / bright      : hard-knee tanh with bright pre-emphasis (hats)
 *
 *  All algorithms include:
 *    – DC blocking at output (1 Hz one-pole)
 *    – Gain compensation to maintain perceived loudness at zero drive
 *    – Per-sample parameter smoothing
 *    – Pre/post anti-aliasing shelves to reduce aliasing artefacts
 */
class SaturationProcessor
{
public:
    SaturationProcessor();

    void prepare (double sampleRate);
    void reset();

    void setDrive (float driveAmount);    // 0..2
    void setMode  (int   algorithmMode); // 0..3

    void processBlock (float* buffer, int numSamples);

private:
    double sampleRate = 44100.0;

    float drive = 0.0f;
    int   mode  = 0;
    float smDrive = 0.0f;
    float smCoeff = 0.0f;

    // DC blocker state
    float dcIn  = 0.0f;
    float dcOut = 0.0f;
    float dcCoeff = 0.0f;

    // Anti-aliasing one-pole low-pass state
    float aaState = 0.0f;
    float aaCoeff = 0.0f;

    // Pre-emphasis state (first-order shelving)
    float preState = 0.0f;

    void updateCoefficients();

    // Saturation algorithms (inline for speed)
    static float tapeSat    (float x, float drv);
    static float tubeSat    (float x, float drv);
    static float transistorSat (float x, float drv);
    static float fetSat     (float x, float drv);

    static float makeCoeff (float timeSeconds, double sr)
    {
        return std::exp (-1.0f / static_cast<float> (sr * timeSeconds));
    }
};
