#include "TransientShaper.h"
#include <cmath>

TransientShaper::TransientShaper()
{
    updateCoefficients();
}

void TransientShaper::prepare (double sr, int /*numChannels*/)
{
    sampleRate = sr;
    updateCoefficients();
    reset();
}

void TransientShaper::reset()
{
    for (auto& c : ch)
        c = {};
    smPunch = 0.0f;
    smSust  = 0.0f;
}

void TransientShaper::setPunch (float v)
{
    punch = juce::jlimit (0.0f, 1.0f, v);
}

void TransientShaper::setSustainAttenuation (float v)
{
    sustainAtt = juce::jlimit (0.0f, 1.0f, v);
}

void TransientShaper::updateCoefficients()
{
    // Fast follower: 0.5 ms attack, 20 ms release
    attackFast  = makeCoeff (0.0005f, sampleRate);
    releaseFast = makeCoeff (0.020f,  sampleRate);

    // Slow follower: 8 ms attack, 120 ms release – tracks body, not onset
    attackSlow  = makeCoeff (0.008f,  sampleRate);
    releaseSlow = makeCoeff (0.120f,  sampleRate);

    // Gain smoothing: 4 ms – fast enough to track transients, slow enough to avoid zipper
    gainSmCoeff = makeCoeff (0.004f, sampleRate);

    // Parameter smoothing: 20 ms
    smCoeff = makeCoeff (0.020f, sampleRate);
}

void TransientShaper::processBlock (float* buffer, int numSamples, int channel)
{
    if (punch < 0.001f && sustainAtt < 0.001f)
        return;

    const int ch_idx = juce::jlimit (0, 1, channel);
    auto& state = ch[static_cast<size_t> (ch_idx)];

    for (int i = 0; i < numSamples; ++i)
    {
        // Smooth parameters per sample
        smPunch += (punch      - smPunch) * (1.0f - smCoeff);
        smSust  += (sustainAtt - smSust)  * (1.0f - smCoeff);

        const float x    = buffer[i];
        const float absX = std::abs (x);

        // ── Fast envelope (onset detector) ───────────────────────────────
        if (absX > state.envFast)
            state.envFast = attackFast  * state.envFast + (1.0f - attackFast)  * absX;
        else
            state.envFast = releaseFast * state.envFast + (1.0f - releaseFast) * absX;

        // ── Slow envelope (body tracker) ──────────────────────────────────
        if (absX > state.envSlow)
            state.envSlow = attackSlow  * state.envSlow + (1.0f - attackSlow)  * absX;
        else
            state.envSlow = releaseSlow * state.envSlow + (1.0f - releaseSlow) * absX;

        // ── Transient component = fast ahead of slow ──────────────────────
        const float transient = juce::jmax (0.0f, state.envFast - state.envSlow);
        // Normalise by slow env so gain is relative, not absolute
        const float norm = state.envSlow > 0.001f
                           ? transient / state.envSlow
                           : transient;

        // ── Punch gain: amplify transient region ──────────────────────────
        // Using a square-root shape so low amounts still audible
        const float punchGain  = 1.0f + smPunch * std::sqrt (juce::jlimit (0.0f, 1.0f, norm)) * 3.0f;

        // ── Sustain attenuation: reduce body where slow > fast ─────────────
        // When the slow env dominates (tail), reduce gain
        const float isSustain  = juce::jmax (0.0f, state.envSlow - state.envFast) /
                                  juce::jmax (0.001f, state.envSlow);
        const float sustGain   = 1.0f - smSust * isSustain * 0.6f;

        const float targetGain = punchGain * sustGain;

        // Smooth the gain to avoid clicks
        state.gainSmooth += (targetGain - state.gainSmooth) * (1.0f - gainSmCoeff);

        buffer[i] = juce::jlimit (-2.0f, 2.0f, x * state.gainSmooth);
    }
}
