#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class RehabLookAndFeel : public juce::LookAndFeel_V4
{
public:
    RehabLookAndFeel()
    {
        setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xFF505050));
        setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour(juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
        setColour(juce::Slider::textBoxHighlightColourId, juce::Colour(0x33E8C84A));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xFFAAAAAA));
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xFF0D0D0D));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xFF2A2A2A));
        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xFF0D0D0D));
        setColour(juce::PopupMenu::textColourId, juce::Colour(0xFFAAAAAA));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xFF1E1E1E));
    }

    void drawRotarySlider(juce::Graphics& g,
        int x, int y, int width, int height,
        float sliderPos, float startAngle, float endAngle,
        juce::Slider& slider) override
    {
        const float cx = x + width * 0.5f;
        const float cy = y + height * 0.5f;
        const float R = juce::jmin(width, height) * 0.5f - 7.0f;
        const float angle = startAngle + sliderPos * (endAngle - startAngle);

        {
            juce::Path p;
            p.addCentredArc(cx, cy, R, R, 0.0f, startAngle, endAngle, true);
            g.setColour(juce::Colour(0xFF1C1C1C));
            g.strokePath(p, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved,
                juce::PathStrokeType::rounded));
        }

        if (sliderPos > 0.001f)
        {
            juce::Path p;
            p.addCentredArc(cx, cy, R, R, 0.0f, startAngle, angle, true);
            juce::ColourGradient gr(juce::Colour(0xFFFFD966), cx - R, cy,
                juce::Colour(0xFFC4A030), cx + R, cy, false);
            g.setGradientFill(gr);
            g.strokePath(p, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved,
                juce::PathStrokeType::rounded));
        }

        const float kr = R * 0.67f;
        g.setColour(juce::Colour(0x66000000));
        g.fillEllipse(cx - kr, cy - kr + 2.0f, kr * 2.0f, kr * 2.0f);

        juce::ColourGradient body(juce::Colour(0xFF2E2E2E), cx - kr, cy - kr,
            juce::Colour(0xFF181818), cx + kr, cy + kr, false);
        g.setGradientFill(body);
        g.fillEllipse(cx - kr, cy - kr, kr * 2.0f, kr * 2.0f);

        g.setColour(juce::Colour(0xFF333333));
        g.drawEllipse(cx - kr, cy - kr, kr * 2.0f, kr * 2.0f, 0.8f);

        juce::ColourGradient shine(juce::Colour(0x12FFFFFF), cx - kr * 0.2f, cy - kr * 0.3f,
            juce::Colours::transparentBlack, cx + kr * 0.3f, cy + kr * 0.3f, false);
        g.setGradientFill(shine);
        g.fillEllipse(cx - kr + 1, cy - kr + 1, kr * 2.0f - 2, kr * 2.0f - 2);

        const float px = cx + std::sin(angle) * kr * 0.52f;
        const float py = cy - std::cos(angle) * kr * 0.52f;
        g.setColour(juce::Colour(0x44E8C84A));
        g.fillEllipse(px - 4.0f, py - 4.0f, 8.0f, 8.0f);
        g.setColour(juce::Colour(0xFFFFD966));
        g.fillEllipse(px - 2.0f, py - 2.0f, 4.0f, 4.0f);

        (void)slider;
    }

    void drawComboBox(juce::Graphics& g, int width, int height,
        bool, int, int, int, int, juce::ComboBox&) override
    {
        auto b = juce::Rectangle<float>(0, 0, (float)width, (float)height);
        g.setColour(juce::Colour(0xFF0D0D0D));
        g.fillRoundedRectangle(b, 6.0f);
        g.setColour(juce::Colour(0xFF2A2A2A));
        g.drawRoundedRectangle(b.reduced(0.5f), 6.0f, 0.8f);

        juce::Path arrow;
        const float ax = width - 16.0f, ay = height * 0.5f;
        arrow.addTriangle(ax, ay - 3, ax + 7, ay - 3, ax + 3.5f, ay + 3);
        g.setColour(juce::Colour(0xFF404040));
        g.fillPath(arrow);
    }

    void positionComboBoxText(juce::ComboBox& box, juce::Label& label) override
    {
        label.setBounds(10, 0, box.getWidth() - 26, box.getHeight());
        label.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::bold));
    }

    juce::Font getLabelFont(juce::Label&) override
    {
        return juce::Font(juce::Font::getDefaultMonospacedFontName(), 9.0f, juce::Font::bold);
    }
};

class WaveformDisplay : public juce::Component, public juce::Timer
{
public:
    WaveformDisplay() { startTimerHz(30); waveBuffer.assign(BUF, 0.0f); }
    ~WaveformDisplay() override { stopTimer(); }

    void pushSamples(const float* data, int n)
    {
        for (int i = 0; i < n; ++i)
        {
            waveBuffer[writePos] = data[i];
            writePos = (writePos + 1) % BUF;
        }
    }

    void timerCallback() override { repaint(); }

    void paint(juce::Graphics& g) override
    {
        auto b = getLocalBounds().toFloat();
        const float W = b.getWidth(), H = b.getHeight(), mid = H * 0.5f;

        g.setColour(juce::Colour(0xFF0A0A0A));
        g.fillRoundedRectangle(b, 8.0f);

        g.setColour(juce::Colour(0xFF141414));
        for (int i = 1; i < 4; ++i)
            g.drawHorizontalLine((int)(b.getY() + H * i / 4.0f), b.getX() + 1, b.getRight() - 1);
        for (int i = 1; i < 8; ++i)
            g.drawVerticalLine((int)(b.getX() + W * i / 8.0f), b.getY() + 1, b.getBottom() - 1);

        g.setColour(juce::Colour(0x28FF4444));
        g.drawHorizontalLine((int)(b.getY() + H * 0.08f), b.getX() + 4, b.getRight() - 4);
        g.drawHorizontalLine((int)(b.getY() + H * 0.92f), b.getX() + 4, b.getRight() - 4);

        juce::Path fp;
        fp.startNewSubPath(b.getX(), b.getY() + mid);
        for (int i = 0; i < BUF; ++i)
        {
            const float s = waveBuffer[(writePos + i) % BUF];
            fp.lineTo(b.getX() + (float)i / (BUF - 1) * W, b.getY() + mid - s * mid * 0.84f);
        }
        fp.lineTo(b.getRight(), b.getY() + mid);
        fp.closeSubPath();

        juce::ColourGradient fg(juce::Colour(0x28E8C84A), 0, b.getY(),
            juce::Colour(0x04E8C84A), 0, b.getBottom(), false);
        g.setGradientFill(fg);
        g.fillPath(fp);

        juce::Path lp;
        for (int i = 0; i < BUF; ++i)
        {
            const float s = waveBuffer[(writePos + i) % BUF];
            const float px = b.getX() + (float)i / (BUF - 1) * W;
            const float py = b.getY() + mid - s * mid * 0.84f;
            if (i == 0) lp.startNewSubPath(px, py); else lp.lineTo(px, py);
        }

        juce::ColourGradient lg(juce::Colour(0xFFFFD966), b.getX(), 0,
            juce::Colour(0xFFC4A030), b.getRight(), 0, false);
        g.setGradientFill(lg);
        g.strokePath(lp, juce::PathStrokeType(1.5f, juce::PathStrokeType::curved));

        g.setColour(juce::Colour(0xFF1E1E1E));
        g.drawRoundedRectangle(b.reduced(0.5f), 8.0f, 0.8f);
        g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 8.0f, juce::Font::plain));
        g.setColour(juce::Colour(0xFF252525));
        g.drawText("WAVEFORM OUTPUT", b.reduced(8, 6), juce::Justification::topLeft);
    }

private:
    static constexpr int BUF = 512;
    std::vector<float> waveBuffer;
    int writePos = 0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(WaveformDisplay)
};

class VerticalLevelMeter : public juce::Component, public juce::Timer
{
public:
    VerticalLevelMeter() { startTimerHz(30); }
    ~VerticalLevelMeter() override { stopTimer(); }

    void setLevel(float l, float r)
    {
        levelL = juce::jlimit(0.0f, 1.2f, l);
        levelR = juce::jlimit(0.0f, 1.2f, r);
    }

    void timerCallback() override
    {
        levelL *= 0.90f;
        levelR *= 0.90f;
        repaint();
    }

    void paint(juce::Graphics& g) override
    {
        auto b = getLocalBounds().reduced(4);

        const int channelGap = 8;
        const int labelH = 10;
        const int meterTop = b.getY() + labelH + 4;
        const int meterBottom = b.getBottom() - 2;
        const int meterHeight = meterBottom - meterTop;
        const int meterWidth = (b.getWidth() - channelGap) / 2;

        auto drawChannel = [&](float level, int x, const juce::String& label)
            {
                auto track = juce::Rectangle<float>((float)x, (float)meterTop, (float)meterWidth, (float)meterHeight);

                g.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 8.0f, juce::Font::plain));
                g.setColour(juce::Colour(0xFF3A3A3A));
                g.drawText(label, x, b.getY(), meterWidth, labelH, juce::Justification::centred);

                g.setColour(juce::Colour(0xFF161616));
                g.fillRoundedRectangle(track, 3.0f);

                g.setColour(juce::Colour(0xFF232323));
                g.drawRoundedRectangle(track, 3.0f, 0.8f);

                const float pct = juce::jlimit(0.0f, 1.0f, level);
                if (pct > 0.001f)
                {
                    const float fillH = track.getHeight() * pct;
                    juce::Rectangle<float> fill(track.getX() + 1.0f,
                        track.getBottom() - fillH - 1.0f,
                        track.getWidth() - 2.0f,
                        fillH);

                    juce::ColourGradient gr(juce::Colour(0xFF2F6F2F), fill.getCentreX(), fill.getBottom(),
                        juce::Colour(0xFFE8C84A), fill.getCentreX(), fill.getY(), false);
                    g.setGradientFill(gr);
                    g.fillRoundedRectangle(fill, 2.0f);
                }
            };

        drawChannel(levelL, b.getX(), "L");
        drawChannel(levelR, b.getX() + meterWidth + channelGap, "R");
    }

private:
    float levelL = 0.0f, levelR = 0.0f;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VerticalLevelMeter)
};

class LabelledKnob : public juce::Component
{
public:
    juce::Slider slider;

    explicit LabelledKnob(const juce::String& name)
    {
        label.setText(name.toUpperCase(), juce::dontSendNotification);
        label.setJustificationType(juce::Justification::centred);
        label.setFont(juce::Font(juce::Font::getDefaultMonospacedFontName(), 8.0f, juce::Font::bold));
        label.setColour(juce::Label::textColourId, juce::Colour(0xFF3E3E3E));

        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 64, 14);

        addAndMakeVisible(slider);
        addAndMakeVisible(label);
    }

    void resized() override
    {
        auto b = getLocalBounds();
        label.setBounds(b.removeFromBottom(14));
        b.removeFromBottom(4);
        slider.setBounds(b);
    }

private:
    juce::Label label;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(LabelledKnob)
};

class RehabAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    RehabAudioProcessorEditor(RehabAudioProcessor&);
    ~RehabAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

    void pushWaveformSamples(const float* data, int n) { waveformDisplay.pushSamples(data, n); }
    void setInputLevels(float l, float r) { inMeter.setLevel(l, r); }
    void setOutputLevels(float l, float r) { outMeter.setLevel(l, r); }

private:
    RehabAudioProcessor& audioProcessor;
    RehabLookAndFeel rehabLAF;

    WaveformDisplay waveformDisplay;
    VerticalLevelMeter inMeter;
    VerticalLevelMeter outMeter;

    juce::Label modeLabel;
    juce::ComboBox drumModeBox;
    juce::ComboBox satTypeBox;
    juce::ComboBox clipModeBox;

    LabelledKnob hitKnob{ "Hit" };
    LabelledKnob punchKnob{ "Punch" };
    LabelledKnob toneKnob{ "Tone" };
    LabelledKnob satDriveKnob{ "Sat" };
    LabelledKnob clipAmountKnob{ "Clip" };
    LabelledKnob mixKnob{ "Mix" };
    LabelledKnob outputKnob{ "Out" };

    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    std::unique_ptr<ComboBoxAttachment> drumModeAttachment;
    std::unique_ptr<ComboBoxAttachment> satTypeAttachment;
    std::unique_ptr<ComboBoxAttachment> clipModeAttachment;

    std::unique_ptr<SliderAttachment> hitAttachment;
    std::unique_ptr<SliderAttachment> toneAttachment;
    std::unique_ptr<SliderAttachment> punchAttachment;
    std::unique_ptr<SliderAttachment> satDriveAttachment;
    std::unique_ptr<SliderAttachment> clipAmountAttachment;
    std::unique_ptr<SliderAttachment> mixAttachment;
    std::unique_ptr<SliderAttachment> outputAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RehabAudioProcessorEditor)
};