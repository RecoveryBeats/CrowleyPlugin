#include "Parameters.h"

namespace Parameters
{
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout()
    {
        std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

        juce::StringArray drumModes{ "808", "Kick", "Snare", "Closed Hat", "Open Hat" };
        params.push_back(std::make_unique<juce::AudioParameterChoice>(
            juce::ParameterID{ "drumMode", 1 },
            "Drum Mode",
            drumModes,
            0
        ));

        params.push_back(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{ "hit", 1 },
            "Hit",
            juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),
            0.0f,
            juce::String(),
            juce::AudioProcessorParameter::genericParameter,
            [](float value, int) { return juce::String(value * 100.0f, 0) + "%"; },
            [](const juce::String& text) { return text.getFloatValue() / 100.0f; }
        ));

        params.push_back(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{ "inputGain", 1 },
            "Input Gain",
            juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f),
            0.0f,
            "dB"
        ));

        params.push_back(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{ "tone", 1 },
            "Tone",
            juce::NormalisableRange<float>(-1.0f, 1.0f, 0.01f),
            0.0f,
            juce::String(),
            juce::AudioProcessorParameter::genericParameter,
            [](float value, int)
            {
                if (value > 0.0f)
                    return "+" + juce::String(value * 100.0f, 0) + "%";
                return juce::String(value * 100.0f, 0) + "%";
            },
            [](const juce::String& text) { return text.getFloatValue() / 100.0f; }
        ));

        params.push_back(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{ "punch", 1 },
            "Punch",
            juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),
            0.0f,
            juce::String(),
            juce::AudioProcessorParameter::genericParameter,
            [](float value, int) { return juce::String(value * 100.0f, 0) + "%"; },
            [](const juce::String& text) { return text.getFloatValue() / 100.0f; }
        ));

        params.push_back(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{ "satDrive", 1 },
            "Saturation",
            juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),
            0.0f,
            juce::String(),
            juce::AudioProcessorParameter::genericParameter,
            [](float value, int) { return juce::String(value * 100.0f, 0) + "%"; },
            [](const juce::String& text) { return text.getFloatValue() / 100.0f; }
        ));

        params.push_back(std::make_unique<juce::AudioParameterChoice>(
            juce::ParameterID{ "satType", 1 },
            "Sat Type",
            juce::StringArray{ "Soft", "Tube", "Clip" },
            0
        ));

        params.push_back(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{ "clipAmount", 1 },
            "Clip",
            juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),
            0.0f,
            juce::String(),
            juce::AudioProcessorParameter::genericParameter,
            [](float value, int) { return juce::String(value * 100.0f, 0) + "%"; },
            [](const juce::String& text) { return text.getFloatValue() / 100.0f; }
        ));

        params.push_back(std::make_unique<juce::AudioParameterChoice>(
            juce::ParameterID{ "clipMode", 1 },
            "Clip Mode",
            juce::StringArray{ "Soft", "Hard" },
            0
        ));

        params.push_back(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{ "mix", 1 },
            "Mix",
            juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f),
            1.0f,
            juce::String(),
            juce::AudioProcessorParameter::genericParameter,
            [](float value, int) { return juce::String(value * 100.0f, 0) + "%"; },
            [](const juce::String& text) { return text.getFloatValue() / 100.0f; }
        ));

        params.push_back(std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID{ "output", 1 },
            "Output",
            juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f),
            0.0f,
            "dB"
        ));

        return { params.begin(), params.end() };
    }
}