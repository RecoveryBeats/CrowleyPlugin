#include "PluginProcessor.h"
#include "PluginEditor.h"

RehabAudioProcessor::RehabAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
    : AudioProcessor(BusesProperties()
#if ! JucePlugin_IsMidiEffect
#if ! JucePlugin_IsSynth
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
#endif
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)
#endif
    )
#endif
{
}

RehabAudioProcessor::~RehabAudioProcessor() = default;

void RehabAudioProcessor::prepareToPlay(double sampleRate, int /*samplesPerBlock*/)
{
    transientShaper.prepare(sampleRate, getTotalNumOutputChannels());
    saturationProcessor.prepare(sampleRate);
    clipperProcessor.prepare(sampleRate);

    transientShaper.reset();
    saturationProcessor.reset();
    clipperProcessor.reset();

    lowState.fill(0.0f);
    highState.fill(0.0f);
}

void RehabAudioProcessor::releaseResources()
{
}

bool RehabAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
        && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;

    return true;
}

RehabAudioProcessor::ModeScaling RehabAudioProcessor::getModeScaling(int mode)
{
    switch (mode)
    {
    case 0: return { 0.50f, 1.30f, 0.60f, 0, 0 }; // 808
    case 1: return { 1.60f, 1.00f, 1.40f, 1, 1 }; // Kick
    case 2: return { 1.80f, 1.20f, 1.10f, 1, 0 }; // Snare
    case 3: return { 1.20f, 0.50f, 0.60f, 2, 0 }; // Closed Hat
    case 4: return { 0.90f, 0.60f, 0.70f, 0, 0 }; // Open Hat
    default: return { 1.00f, 1.00f, 1.00f, 0, 0 };
    }
}

void RehabAudioProcessor::updateToneState(float inputSample, int channel)
{
    const auto ch = static_cast<size_t> (juce::jlimit(0, 1, channel));

    lowState[ch] += 0.08f * (inputSample - lowState[ch]);

    const float highPass = inputSample - lowState[ch];
    highState[ch] += 0.12f * (highPass - highState[ch]);
}

float RehabAudioProcessor::applyTone(float inputSample, int channel) const
{
    const auto ch = static_cast<size_t> (juce::jlimit(0, 1, channel));
    const float tone = juce::jlimit(-1.0f, 1.0f, currentTone);

    const float low = lowState[ch];
    const float high = highState[ch];

    return inputSample + (high * tone * 0.8f) - (low * tone * 0.5f);
}

void RehabAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& /*midi*/)
{
    juce::ScopedNoDenormals noDenormals;

    const int totalNumInputChannels = getTotalNumInputChannels();
    const int totalNumOutputChannels = getTotalNumOutputChannels();
    const int numSamples = buffer.getNumSamples();

    for (int channel = totalNumInputChannels; channel < totalNumOutputChannels; ++channel)
        buffer.clear(channel, 0, numSamples);

    float inputPeakL = 0.0f;
    float inputPeakR = 0.0f;

    if (totalNumInputChannels > 0)
        inputPeakL = buffer.getMagnitude(0, 0, numSamples);
    if (totalNumInputChannels > 1)
        inputPeakR = buffer.getMagnitude(1, 0, numSamples);
    else
        inputPeakR = inputPeakL;

    currentDrumMode = *apvts.getRawParameterValue("drumMode");
    currentHit = *apvts.getRawParameterValue("hit");
    currentInputGain = *apvts.getRawParameterValue("inputGain");
    currentTone = *apvts.getRawParameterValue("tone");
    currentPunch = *apvts.getRawParameterValue("punch");
    currentSatDrive = *apvts.getRawParameterValue("satDrive");
    currentClipAmount = *apvts.getRawParameterValue("clipAmount");
    currentMix = *apvts.getRawParameterValue("mix");
    currentOutput = *apvts.getRawParameterValue("output");

    const ModeScaling scaling = getModeScaling(static_cast<int> (currentDrumMode));

    const float inputGainLinear = juce::Decibels::decibelsToGain(currentInputGain);
    const float outputGainLinear = juce::Decibels::decibelsToGain(currentOutput);

    const float hit = juce::jlimit(0.0f, 1.0f, currentHit);

    const float transientBoost = 1.0f + hit * 1.2f;
    const float satBoost = 1.0f + hit * 1.0f;
    const float clipBoost = 1.0f + hit * 1.5f;
    const float toneBoost = hit * 0.3f;

    const float effectivePunch =
        currentPunch * scaling.transientMultiplier * transientBoost;

    const float effectiveSatDrive =
        currentSatDrive * scaling.satMultiplier * satBoost;

    const float effectiveClipAmount =
        currentClipAmount * scaling.clipMultiplier * clipBoost;

    const float effectiveTone = juce::jlimit(-1.0f, 1.0f, currentTone + toneBoost);

    transientShaper.setAttack(effectivePunch);
    saturationProcessor.setDrive(effectiveSatDrive);
    clipperProcessor.setAmount(effectiveClipAmount);

    clipperProcessor.setMode(static_cast<int> (currentDrumMode) != 1);

    auto dry = buffer;
    currentTone = effectiveTone;

    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        float* channelData = buffer.getWritePointer(channel);
        const float* dryData = dry.getReadPointer(channel);

        for (int i = 0; i < numSamples; ++i)
        {
            channelData[i] *= inputGainLinear;
            updateToneState(channelData[i], channel);
            channelData[i] = applyTone(channelData[i], channel);
        }

        transientShaper.processBlock(channelData, numSamples, channel);
        saturationProcessor.processBlock(channelData, numSamples);
        clipperProcessor.processBlock(channelData, numSamples);

        const float mix = juce::jlimit(0.0f, 1.0f, currentMix);

        for (int i = 0; i < numSamples; ++i)
        {
            const float wet = channelData[i];
            const float mixed = dryData[i] + (wet - dryData[i]) * mix;
            channelData[i] = std::tanh(mixed * outputGainLinear * 1.2f);
        }
    }

    float outputPeakL = 0.0f;
    float outputPeakR = 0.0f;

    if (totalNumInputChannels > 0)
        outputPeakL = buffer.getMagnitude(0, 0, numSamples);
    if (totalNumInputChannels > 1)
        outputPeakR = buffer.getMagnitude(1, 0, numSamples);
    else
        outputPeakR = outputPeakL;

    if (auto* editor = dynamic_cast<RehabAudioProcessorEditor*> (getActiveEditor()))
    {
        if (totalNumInputChannels > 0)
            editor->pushWaveformSamples(buffer.getReadPointer(0), numSamples);

        editor->setInputLevels(inputPeakL, inputPeakR);
        editor->setOutputLevels(outputPeakL, outputPeakR);
    }
}

juce::AudioProcessorEditor* RehabAudioProcessor::createEditor()
{
    return new RehabAudioProcessorEditor(*this);
}

bool RehabAudioProcessor::hasEditor() const
{
    return true;
}

const juce::String RehabAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool RehabAudioProcessor::acceptsMidi() const
{
#if JucePlugin_WantsMidiInput
    return true;
#else
    return false;
#endif
}

bool RehabAudioProcessor::producesMidi() const
{
#if JucePlugin_ProducesMidiOutput
    return true;
#else
    return false;
#endif
}

bool RehabAudioProcessor::isMidiEffect() const
{
#if JucePlugin_IsMidiEffect
    return true;
#else
    return false;
#endif
}

double RehabAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int RehabAudioProcessor::getNumPrograms()
{
    return 1;
}

int RehabAudioProcessor::getCurrentProgram()
{
    return 0;
}

void RehabAudioProcessor::setCurrentProgram(int /*index*/)
{
}

const juce::String RehabAudioProcessor::getProgramName(int /*index*/)
{
    return {};
}

void RehabAudioProcessor::changeProgramName(int /*index*/, const juce::String& /*newName*/)
{
}

void RehabAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    const auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void RehabAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));

    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType()))
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new RehabAudioProcessor();
}